<!--
  - Coded by Hameed Abdul-lateef Ayomide
  - Email: Hameedayomide@gmail.com
  - Website: http://www.devayo.me
  - Instagram: @hamdalofficial
-->

<?php
    ini_set('display_errors', '1');

    use League\Csv\Reader;
    use League\Csv\Statement;

    require 'csv-9.1.0/autoload.php';


    $csv = Reader::createFromPath('data/dummy.csv', 'r');
    $csv->setHeaderOffset(0); //set the CSV header offset

    $stmt = (new Statement())
    ->offset(0)
    ;

    $fields = $stmt->process($csv);
    $reply = '';
    foreach ($fields as $field) {
      if (!empty($_GET['message'])) {
        if ($field['question'] == cleanupQuestion($_GET['message'])) {
          $reply = $field['answer'];
        } else {
          $reply = "I'm sorry, i don't understand the question";
        }
      }
    }

    if (!empty($reply)) {
      echo $reply;
    }

    function cleanupQuestion($message) {
      $message = str_ireplace('?', '', $message);      
      $message = trim($message);
      return $message;
    }   
?> 