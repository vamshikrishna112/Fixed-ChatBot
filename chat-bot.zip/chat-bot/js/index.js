(function() {
    let chatMessageCounter = $('.chat-message-counter');
    let chatFeedback = $('.chat-feedback');
    let intent = '';
    let target = '';
    let chatContainer = $('.chat-history');
    let userMessageField = $('#message');
    let userMessage;
    let botReply = '';

    let messageTime = '';
    let replyTime = '';

    // Set first message time to when website was loaded
    let dateObj = new Date();
    $('.chat-time').text(dateObj.toLocaleTimeString());

    $('#live-chat header').on('click', function() {

        $('.chat').slideToggle(300, 'swing');
        $('.chat-message-counter').fadeToggle(300, 'swing');

    });

    // $('.chat-close').on('click', function(e) { 	e.preventDefault();
    // 	$('#live-chat').fadeOut(300); });

    $('#new-message-form').submit(function(e) {
        e.preventDefault();

        clearFeedback();
        let userMessage = $('#message').val();

        showUserMessage(userMessage);

        $.ajax({
            type: "GET",
            url: "http://localhost/chat-bot/script.php",
            data: {
                'message': userMessage
            },
            success: function(data) {
                console.log(data);
                if (data != '') {
                    botReply = data;
                    showBotReply(botReply);
                } else {
                    botReply = 'An error occured' // Error report -  Microsoft style :)
                    showBotReply(botReply);
                }
            },
            error: function() {
                console.log('error');
                chatFeedback.css('color', 'red');
                chatFeedback.text('an error occured, message could not be sent');
            }
        });
    });

    function clearFeedback() {
        // chatFeedback.css('color', 'red');
        chatFeedback.text('');
    }

    function showBotReply(message) {
        let dateObj = new Date();
        replyTime = dateObj.toLocaleTimeString();

        let chatMessageTemplateBot = `
			<div class="chat-message clearfix">

				<img src="images/avatar.png" alt="" width="32" height="32">

				<div class="chat-message-content clearfix">

					<span class="chat-time">${replyTime}</span>

						<h5>Bot</h5> 

					<p>${message}</p>

				</div>
			</div>
			<hr>
		`;

        chatContainer.append(chatMessageTemplateBot);
        // Scroll chat to end
        scrollChatContainerBottom();
        // Increase chat message counter
        chatMessageCounter.text(parseInt(chatMessageCounter.text()) + 1);
    }

    function showUserMessage(message) {
        let dateObj = new Date();
        messageTime = dateObj.toLocaleTimeString();

        let chatMessageTemplateUser = `
			<div class="chat-message clearfix">

				<img src="images/avatar.png" alt="" width="32" height="32">

				<div class="chat-message-content clearfix">

					<span class="chat-time">${messageTime}</span>

						<h5>You</h5> 

					<p>${message}</p>

				</div>
			</div>
			<hr>
		`;

        chatContainer.append(chatMessageTemplateUser);
        // Scroll chat to end
        scrollChatContainerBottom();
        // Clear chat input field
        userMessageField.val('');
        // Increase chat message counter
        chatMessageCounter.text(parseInt(chatMessageCounter.text()) + 1);
    }

    function scrollChatContainerTop() {
        chatContainer.scrollTop(0);
    }

    function scrollChatContainerBottom() {
        chatContainer.scrollTop(parseInt(chatContainer.prop('scrollHeight')));
    }

})();